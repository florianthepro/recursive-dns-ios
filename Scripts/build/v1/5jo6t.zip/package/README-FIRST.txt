Build fehlgeschlagen.

Diese ZIP enthlt den bis zum Fehler erzeugten Quellstand und smtliche verfgbaren Protokolle. Mageblich ist logs/build.log beziehungsweise das letzte erzeugte Protokoll.
